---
name: amazon-aplus-image
description: "Internal Amazon A+ module creative guidance under the Director using module-specific requirements and supported claims."
---

# Amazon A+ Image

## 用途与适用场景
Internal Amazon A+ module creative guidance under the Director using module-specific requirements and supported claims.

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
读取 knowledge/amazon/aplus-rules.md，先明确 Basic/Premium 和拟使用模块，按后台模块规格定画布。
规划产品开场、证据细节、真实用途、本品牌型号比较、规格模块；避免重复图库内容的无意义拼贴。
长文保留在模块文本区域，图中仅保留必要短句；提供准确 alt text，核对移动端预览。
不使用价格促销、外链、二维码、保修保证、无证奖项或竞品对比。
使用 templates/prompts/aplus.md；输出模块图像方案、分离的模块文案和 alt text。
QC 包括产品一致性、短文可读性、模块尺寸、声明证据和平台限制；不代替 Amazon 审核。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
