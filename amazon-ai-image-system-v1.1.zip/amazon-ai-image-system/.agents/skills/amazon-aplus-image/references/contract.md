# Amazon A+ Image 数据与调用契约

先定位包含 AGENTS.md、schemas/、scripts/ 的仓库根目录。所有 CLI 从根目录运行。
这是项目相对定位规则，不依赖创建者个人目录。完整操作：根目录 docs/operator-workflow.md。

事实字段使用 value/status/sources/note；未知值 null，不能填虚假产品示例。
Product Card 属性见 schemas/product.schema.json；Image Plan 见 schemas/image-plan.schema.json。
控制状态只由 Director 使用 scripts/workflow.py 写入，其他 Agent 返回建议文件。
外部引用路径都必须复制到 Job 内并登记 SHA256，避免 clone 后失效。

分析：读取 knowledge/product/，保留证据与冲突。
构图：读取当前图型规则及 knowledge/style/ 下相关类别。
生成前：运行 scripts/validate_job.py JOB/image-job.json --generation，再由 begin 验证 Prompt。
QC：报告必须包含 job_id、image_id、asset_sha256、confirmation_digest、五项 checks 和 issues。
脚本日志面向管理员；向运营解释最必要的问题，不展示内部堆栈。
