---
name: amazon-secondary-image
description: "Internal Amazon feature, lifestyle, size, detail and comparison image guidance under the Director; never bypass product confirmation."
---

# Amazon Secondary Image

## 用途与适用场景
Internal Amazon feature, lifestyle, size, detail and comparison image guidance under the Director; never bypass product confirmation.

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
用功能证据、真实场景、尺寸图、细节特写分别回答买家问题。
场景中安装位置、接触、遮挡、受力、视角和比例须符合实际用途；不能为画面美观改变结构。
文字层级为短标题、证据、少量标签；不要遮盖关键部件，手机预览保持可读。
尺寸图只用确认尺寸并显示单位，对比只用有证据的对象和差异，不虚构竞品劣势。
遵守 knowledge/amazon/secondary-image-rules.md；选择 lifestyle/feature/size 模板。
输出逐图构图与 Prompt 约束；QC 必查物理逻辑、文字数字、配件暗示和证据一致性。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
