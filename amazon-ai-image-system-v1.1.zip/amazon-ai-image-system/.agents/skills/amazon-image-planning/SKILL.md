---
name: amazon-image-planning
description: "Internal image-set planning for the Director using confirmed facts, distinct buyer questions and evidence; not generation."
---

# Amazon Image Planning

## 用途与适用场景
Internal image-set planning for the Director using confirmed facts, distinct buyer questions and evidence; not generation.

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
先读产品事实、站点和图型。根据需求规划张数，不机械凑七图。
七图常用顺序：主图、功能、场景、尺寸、细节、比较、另一场景；缺尺寸/比较依据时替换为有证据的主题。
每张图具备独立 buyer_question、evidence、message、visible_copy、composition、scene、constraints、画布。
用 main/secondary/aplus Skill 确定图型边界，knowledge/style 选对应类目。
确认前返回草案，确认后只能把同一方案转换为执行细节。更改方案必须交回 Director 重新确认。
检查场景、卖点和构图是否重复，中文解释方案，US 面向买家的文字使用自然英文。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
