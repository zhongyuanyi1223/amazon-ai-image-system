---
name: amazon-product-analysis
description: "Internal evidence-based product analysis for the Director; extract identity, geometry, claims, immutable features and conflicting facts without deciding for the operator."
---

# Amazon Product Analysis

## 用途与适用场景
Internal evidence-based product analysis for the Director; extract identity, geometry, claims, immutable features and conflicting facts without deciding for the operator.

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
逐项核对 SKU/变体、颜色、表面、结构连接、孔位、数量、配件、尺寸与使用方式。
照片可确认可见结构但不能证明材质、认证、承重或实际售卖件数。来源矛盾不自行择一。
给每个不可变特征写可核对的描述，例如“两条横杆、四个连接孔”，避免“不要改变产品”空话。
材质影响外观时标记 material_affects_visual=true。未知尺寸不阻止普通场景图，但不能规划尺寸图。
无功能声明可以明确确认空列表；有声明必须关联证据。
输出拟议 Product Card、事实依据和最必要问题，不修改 Director 的锁定数据。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
