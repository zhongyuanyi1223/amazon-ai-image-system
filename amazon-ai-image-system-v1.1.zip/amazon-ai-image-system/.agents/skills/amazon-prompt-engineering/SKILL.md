---
name: amazon-prompt-engineering
description: "Internal conversion of a confirmed image plan into reference-preserving native OpenAI image prompts and scoped QC repair instructions."
---

# Amazon Prompt Engineering

## 用途与适用场景
Internal conversion of a confirmed image plan into reference-preserving native OpenAI image prompts and scoped QC repair instructions.

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
先运行确认校验，阅读锁定产品、确认方案、站点规则与对应图型 Skill。
从 templates/prompts/product-protection.md 和图型模板构造具体 Prompt：参考图 → 产品保护 → 目的
→ 构图/场景 → 摄影/灯光/材质 → 精确文字 → 技术要求 → 禁止改变内容。
所有占位符都必须替换为已确认事实；缺证据时返回 Director，不用创作填补事实。
记录参考文件的真实相对路径。优先编辑参考图，不让模型重新设计产品。
修复读取最新 FAIL 图片与 QC，引用 qc-repair 模板，保留其他部分；登记 repair_of 图片摘要。
输出纯文本 Prompt 文件，Director 使用 workflow prompt 登记；本角色不调用生图工具。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
