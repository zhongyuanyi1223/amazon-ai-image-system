---
name: amazon-image-director
description: "Route Amazon image, Amazon main image, Amazon secondary image, Amazon product image, Amazon A+, Amazon lifestyle image, Amazon feature image, Amazon size image, Amazon comparison image, Amazon image set requests; generate Amazon images, create Amazon images, edit Amazon images, redesign Amazon images, optimize Amazon images, review Amazon images. 处理帮我做Amazon图片、Amazon七图、这个产品图片重新设计一下、帮我做A+等请求；不用于仓库代码维护。"
---

# Amazon Image Director

## 用途与适用场景
Route Amazon image, Amazon main image, Amazon secondary image, Amazon product image, Amazon A+, Amazon lifestyle image, Amazon feature image, Amazon size image, Amazon comparison image, Amazon image set requests; generate Amazon images, create Amazon images, edit Amazon images, redesign Amazon images, optimize Amazon images, review Amazon images. 处理帮我做Amazon图片、Amazon七图、这个产品图片重新设计一下、帮我做A+等请求；不用于仓库代码维护。

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
1. 找到项目根目录 AGENTS.md，阅读 config/ 三份策略；新建独立 Job，或恢复已有 Job。
2. 使用 intake 和 product-analysis 读取素材，向运营只问必要的 P0 问题。保留冲突来源。
3. 分析阶段调用 image-planning 形成方案草案，再进入 WAITING_FOR_CONFIRMATION。
4. 输出自然语言确认摘要，不能把 JSON 直接丢给运营。得到本次明确确认后调用 confirm。
5. 委派 Prompt Engineer 起草 prompts，逐张登记；begin 成功后才调用当前可用 OpenAI 原生图片工具。
6. 保存工具返回图片并 record。调用 image_qc 检查实际像素与参考图，再登记报告。
7. FAIL 图由 Prompt Engineer 仅按 QC 问题修复，保留其余设计。begin 再次验证，再生成。
8. 全部 PASS 后 export，仅交付 delivery 文件夹；达到修复上限先询问，不循环消耗。

可将分析、规划、Prompt、QC 分别委派给四个对应项目 Agent，逐步等待依赖结果。
工具不支持自定义子 Agent 时，用相同 Skill 顺序执行，并在诊断中说明；不能称已运行多 Agent。
只有 Director 写 Job 和调用生图。用户显式调用内部 Skill 时也回到此流程，不绕过确认。
管理员说“检查当前Amazon AI图片系统”或“检查当前系统”时运行 system_diagnostic.py --run-tests。
普通运营不用理解内部角色名称。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
