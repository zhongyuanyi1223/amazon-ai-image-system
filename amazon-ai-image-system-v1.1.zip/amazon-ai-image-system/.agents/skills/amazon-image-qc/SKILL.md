---
name: amazon-image-qc
description: "Internal visual review of actual generated images against locked product references, physical logic and current Amazon rules; reports PASS or actionable FAIL to the Director."
---

# Amazon Image QC

## 用途与适用场景
Internal visual review of actual generated images against locked product references, physical logic and current Amazon rules; reports PASS or actionable FAIL to the Director.

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
必须打开当前实际生成图和产品参考图，逐张检查，不凭 Prompt 或工具“成功”响应推断 PASS。
产品一致性：结构、形状、比例、数量、颜色、材质、孔位、连接、配件和细节。
物理逻辑：安装方式、手与产品接触、门/家具/墙体关系、遮挡、受力、光影、透视。
平台规则：主图/副图/A+、背景、叠加文字、商标、水印、错误产品和虚假功能。
文字准确性：逐字核对标题、数字、单位、拼写与已确认副本；技术质量检查真实尺寸、清晰度和边缘。
填写 qc-report.template.json，绑定当前图片 SHA256 和 confirmation_digest；任何未解决问题都 FAIL。
问题给出 severity、type、具体位置/描述与 repair_instruction；不能将未查看视为 PASS。
Director 用 validate_qc.py 校验，再用 workflow qc 登记，只有全组 PASS 才可 FINAL。
脚本验证报告一致性，不替代视觉判断。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
