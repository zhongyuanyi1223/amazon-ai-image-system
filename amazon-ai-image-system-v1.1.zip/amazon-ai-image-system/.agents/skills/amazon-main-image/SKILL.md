---
name: amazon-main-image
description: "Internal main-image composition and product-preserving prompt guidance; called only through the Director for an approved main-image slot."
---

# Amazon Main Image

## 用途与适用场景
Internal main-image composition and product-preserving prompt guidance; called only through the Director for an approved main-image slot.

## 输入与输出
输入：当前 Job、Product Card、Image Plan、参考资料和适用规则；按当前阶段读取。
输出：本角色的事实、方案、Prompt 或 QC 结果，返回 Director 持久化。
除 Director 外，收到没有 Job 的直接调用先交回 Director 建立任务。

## 工作步骤、构图与产品保护
目的：在缩略图中准确识别实际销售产品与数量。
读取 knowledge/amazon/main-image-rules.md，按当前类目核验白底、主体占比及技术规格。
保持完整轮廓、真实比例、适当留白、清晰材质与自然接触阴影；禁止裁切关键部分。
禁止添加文字、水印、徽章或无关装饰。区分真实印刷在产品上的商标与后加图形。
优先对真实产品图做保真编辑；纯生成无法可靠保持细节时索取更好源图。
输出构图、产品保护约束和 main Prompt；QC 必查销售件数、配件、背景、边缘与结构。

## Amazon 规则、Prompt 与禁止事项
按图型读取项目根目录 knowledge/amazon/ 的规则，详细执行接口见
[references/contract.md](references/contract.md)。构图不能改变锁定产品信息。
需要 Prompt 时读取项目 templates/prompts/ 中相应模板，不硬编码完整规则。
不得绕过确认、捏造产品事实、直接选择冲突来源或调用外部生图平台。

## QC 要求
阶段输出必须有证据，生成图片必须进入 image-qc。未看到实际图片不得声明 PASS。
